# Install in local Codex

From this extracted folder, add the marketplace:

```bash
codex plugin marketplace add .
```

Then open Codex Plugins, find `d2l-sales-workflows`, and install it.

The plugin contains 23 sales skills. Keep the folder in a stable location so
the local marketplace path remains valid.
