# Approved Examples for Pat Voice

Use these examples to match Pat's sales messaging style. Keep the copy short, specific, and human. Do not turn these into rigid templates.

## LinkedIn Connection Notes

### Healthcare credentialing

```text
Hi [Name] - I work with a few healthcare credentialing boards on their CE programs. Thought it'd be worth connecting.
```

### Trade association

```text
Hi [Name] - I spend a lot of time with associations modernizing member training. Your world felt relevant, so I thought I'd connect.
```

### Banking / financial education

```text
Hi [Name] - I work with teams that manage compliance-heavy member education. Thought it'd be useful to stay connected.
```

## LinkedIn Follow-Ups

### Healthcare credentialing

```text
Healthcare credentialing teams are in a tricky spot right now. CE requirements keep expanding, but the tools behind them do not always keep up. I work with a few organizations thinking through that exact problem. Happy to compare notes if useful. No pressure either way.
```

### Association member education

```text
A lot of associations I talk with are trying to make member learning feel less like a portal and more like part of the member experience. That is usually easier said than done. D2L works with teams tackling that mix of education, engagement, and reporting. Worth swapping notes sometime?
```

## Cold Emails

### Healthcare / CE compliance

Subject: `CE reporting question`

```text
Hi [Name] - healthcare associations are being asked to do more with CE, reporting, and member education than they were a few years ago.

The tricky part is that a lot of teams are still managing that work across tools that were not built for credentialing programs.

D2L works with healthcare associations on CE compliance and member learning, so I thought there may be a relevant conversation here.

Curious if improving CE delivery or reporting is on your radar this year?
```

### Trade / manufacturing training

Subject: `member training at [Association Name]`

```text
Hi [Name] - trade associations are carrying more of the workforce training load than ever.

That gets hard when members need practical training, employers want proof, and the back-end work still falls on a small team.

D2L helps associations manage that kind of member training in one place, from course delivery to reporting.

Worth a quick chat to see if this maps to anything on your side?
```

### Professional development association

Subject: `quick thought on [Association Name]'s learning programs`

```text
Hi [Name] - member education is becoming a bigger part of how associations prove value.

The hard part is making learning easy to find, easy to complete, and easy to report on without adding more work for the team.

D2L works with organizations that are modernizing that experience for members.

Curious if that is a priority for [Association Name] this year?
```

## Warm / Referral Email

```text
Hi [Name] - [Mutual Contact] mentioned you may be thinking about member education and CE delivery.

I work with associations that are trying to make learning easier for members and easier to manage internally.

No big pitch here. Just thought it may be worth a short conversation to see if there is any overlap.

Would next week be worth a quick chat?
```

## Call Follow-Up

```text
Hi [Name] - appreciated the conversation today.

It sounds like your biggest issue is not creating more courses. It is making CE easier to manage, track, and report on without adding more manual work for your team.

I will send over a few examples of how similar groups are handling that in Brightspace.

Let's reconnect next Thursday and see what feels relevant from there.
```

## Breakup Email

```text
Hi [Name] - I've reached out a couple times and have not heard back, which usually means either the timing is not right or I'm not hitting the right problem.

Either way, no worries.

If your CE or member learning program becomes a priority, I'm happy to reconnect.

Take care.
```

## Review Examples

### Too corporate

Original:

```text
We help associations leverage a robust and scalable learning management solution to drive seamless member engagement.
```

Better:

```text
We help associations make member learning easier to run, easier to track, and easier for members to use.
```

### Too vague

Original:

```text
I wanted to connect to learn more about your strategic initiatives this year.
```

Better:

```text
Curious if member education or CE reporting is on your radar this year.
```

### Too pushy

Original:

```text
Please book 30 minutes on my calendar so I can show you how D2L can transform your learning strategy.
```

Better:

```text
Worth a quick chat to see if any of this maps to your world?
```
