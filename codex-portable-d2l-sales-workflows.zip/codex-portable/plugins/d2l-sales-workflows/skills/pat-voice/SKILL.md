---
name: pat-voice
description: >
  apply pat's established sales messaging voice and tone to b2b sales writing and review. use whenever pat asks to write, rewrite, improve, shorten, draft, or review outreach, emails, linkedin messages, follow-ups, call recaps, internal sales notes, or any prospecting copy. also use when pat says something sounds too corporate, too robotic, too salesy, too long, or not like him. default to this skill for sales-related writing without waiting for pat to explicitly ask for his voice. emphasize warm midwest charm, short human language, relevance-first openings, soft calls to action, and d2l brightspace association, credentialing, member-training, healthcare, banking, manufacturing, trade, and professional development context.
---

# Pat Voice

## Operating Standard

Write and review sales communication in Pat's established voice: warm, specific, plainspoken, and low-pressure. Make the message sound like a real person wrote it, not like a vendor email.

Use this voice by default for sales-related writing. Do not announce that the skill is being used.

## Core Voice

Use these traits in every draft:

- Sound human, warm, and grounded.
- Lead with relevance to the buyer, not a compliment and not a pitch.
- Keep sentences short.
- Use simple words.
- Make one clear point per message.
- Use soft asks that feel like an invitation.
- Respect the buyer's time.
- Avoid hype, urgency manufacturing, and corporate fog.

Identity check: would this sound natural if a practical Midwest sales rep sent it to a buyer he actually cared about helping? If not, cut or rewrite.

## Default Workflow

1. Identify the channel: linkedin connection note, linkedin follow-up, cold email, warm email, call follow-up, internal message, or draft review.
2. Identify the buyer context: association, credentialing body, professional development organization, healthcare, banking, manufacturing, trade, or other.
3. Open with something specific about their world. Use provided context first. Do not invent facts.
4. Keep the message short enough to read on a phone.
5. Include only one ask.
6. Before finalizing, remove banned phrases, jargon, extra setup, and soft-but-mushy hedging.

If the user provides a draft, review before rewriting. Flag the exact phrases that sound too corporate or salesy, then provide a tighter version.

## Channel Rules

### LinkedIn Connection Note

Follow these rules:

- Keep under 300 characters.
- Do not pitch.
- Reference something specific about the org type, role, or industry.
- Never open with "Hi [Name], I came across your profile..."
- Use this structure: relevant context plus a low-key reason to connect.

Example shape:

```text
Hi [Name] - I work with a few healthcare credentialing boards on their member education programs. Thought it'd be worth connecting.
```

### LinkedIn Follow-Up After Connection Accepted

Follow these rules:

- Use 3 to 5 sentences max.
- Do not start with "thanks for connecting."
- Do not restate their job title back to them.
- Open with an observation about their world.
- End with one soft CTA.
- Vary structure across a batch so messages do not feel templated.

Example shape:

```text
Healthcare credentialing orgs have a tricky spot right now - CE requirements keep expanding, but the tools most boards are running have not kept pace. I work with a few organizations navigating exactly that. Happy to share what's working if it's ever useful. No pressure either way.
```

### Cold Email

Follow these rules:

- Use a specific or curiosity-led subject line.
- Make the first sentence about them, not Pat or D2L.
- Use 4 to 6 sentences.
- Include one problem, one proof point, and one ask.
- Use a soft CTA such as "Worth a quick chat?"
- Keep it short enough that it does not scroll on mobile.

Subject line patterns:

- `CE credits and Brightspace - quick question`
- `Quick thought on [Association Name]'s CE program`
- `How [similar org] modernized member learning`

Breakup-style final touch:

```text
Hi [Name] - I've reached out a couple times and have not heard back, which usually means either the timing is not right or I'm not hitting the right problem. Either way, no worries. If your CE or credentialing program becomes a priority, I'm happy to reconnect. Take care.
```

### Warm or Referral Email

Follow these rules:

- Acknowledge the shared connection first.
- Keep it no longer than a cold email.
- Make one ask.
- Do not over-explain the referral.

### Call Follow-Up

Follow these rules:

- Use 3 to 5 sentences.
- Recap what the buyer said, not what Pat pitched.
- Include one clear next step.
- Be warm, not gushy.
- Do not over-thank.

## Review Workflow

When reviewing Pat's draft:

1. Start with the biggest issue, not a generic compliment.
2. Flag exact phrases that sound corporate, salesy, long, vague, or robotic.
3. Offer a shorter alternative for each flagged phrase when useful.
4. Provide a clean rewrite in Pat's voice.
5. Cut before adding. Preserve Pat's intent.

Use this review format when helpful:

```markdown
What I'd tighten:
- "[phrase]" -> sounds [too corporate / vague / pushy]. Try: "[alternative]"

Cleaner version:
[rewrite]
```

## Words and Phrases to Avoid

Never use these in final copy unless the user explicitly asks to keep them:

- synergy
- leverage
- robust
- cutting-edge
- best-in-class
- seamless
- holistic
- scalable solutions
- hope this finds you well
- hope your week is going well
- i just wanted to follow up on my last email
- per my last email
- i'd love the opportunity to connect
- circling back
- touching base

Avoid passive hedge piles such as:

- might possibly
- if you'd ever be open to maybe
- i was wondering whether

Avoid platform jargon when buyer-friendly language is clearer. Prefer "the platform your members use for CE credits" over "learning management system" when writing to non-technical buyers.

## Preferred Language

Prefer:

- "Worth a quick chat?"
- "Curious if..."
- "No pressure either way."
- "Happy to share what's working."
- "This may be off-base, but..."
- "Sounds like..."
- "The tricky part is..."
- "Most teams I talk with are trying to..."

Use contractions. They sound human.

## Vertical Calibration

Adjust tone based on the buyer's world:

- Healthcare and clinical: be a little more formal. Lead with credibility, CE compliance, regulatory context, risk reduction, and trust.
- Banking and financial: be conservative. Lead with compliance, audit readiness, consistency, and reduced risk.
- Trade and manufacturing: be practical. Lead with efficiency, cost savings, training consistency, and real-world outcomes.
- Professional development and associations: be conversational and member-centric. Lead with member experience, engagement, modern delivery, and retention.

Read the room. If their signature has credentials and legal disclaimers, keep it tighter and more formal. If their public voice is warmer or member-experience focused, the copy can loosen up.

## D2L Brightspace Proof Points

Use these only when relevant. Do not force them into every message:

- D2L has an existing relationship with PMI for project management credentialing.
- D2L works with healthcare associations on CE compliance programs.
- D2L content is already present on the Associations North Knowledge Hub.
- Risk-averse association buyers often respond well to a "your peers are doing this" angle.

When using proof, keep it light. One proof point is enough.

## Final Quality Check

Before final output, ask:

- Is the first line about them?
- Could this fit on a phone screen?
- Is there only one ask?
- Did any banned phrase sneak in?
- Would a real person text this to a colleague?
- Does it feel respectful instead of pushy?

## Reference Examples

For worked examples and approved patterns, read `references/approved-examples.md` when the user asks for examples, asks to match a prior feel, or when drafting a batch where variation matters.
