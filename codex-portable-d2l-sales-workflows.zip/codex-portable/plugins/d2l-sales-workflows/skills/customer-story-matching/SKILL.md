---
name: customer-story-matching
description: "Use when the task is to match a prospect, account, or outreach draft to the strongest relevant customer story from the attached story CSVs, extract only the most credible proof points, and apply them conservatively in messaging or seller guidance."
---

# Customer Story Matching

Source agent: Prospect Strategy Agent (agt_6a0026e720bc8191be930c36ba48b710)
Source skill URL: https://chatgpt.com/agents/studio/edit/agt_6a0026e720bc8191be930c36ba48b710/skills/hsk_6a00c72e5b808191bd23a144974b3a8c
Short description: Match prospects to the best proof points from story CSVs

## Instructions

Customer Story Matching

Use this skill when the user wants stronger proof, sharper relevance, or customer-story support for prospecting decisions or outreach.

When To Use

Use this skill when the task includes any of the following:

matching a prospect or account to the best customer story, case study, or proof point

selecting industry, use-case, or outcome evidence to support outreach

deciding whether a customer story is credible enough to mention in a message

improving an existing draft by replacing weak generic claims with a better-matched story

deciding that no customer story should be used because the match is weak

Do not use this skill when the user only wants raw prospect ranking or evidence verification with no need for customer-story support.

Grounded Story Sources

Use these attached files as the only default story sources unless the user provides newer or more specific proof material:

Associations Stories - Published.csv


Corporate Stories - Published.csv


Supporting Files

references/story-source-guide.md - use this for the story-file schema summary, preferred matching dimensions, and proof-point extraction rules before you compare stories.

Request Shapes
1. Prospect-to-story match

Example requests:

"Which customer story should I use for this association prospect?"

"Match these Work Now prospects to the strongest D2L story."

Success criteria:

choose the best available story only when the match is credibly strong

explain why the story matches

provide 1-3 safe proof points that can be reused downstream

explicitly say when no story clears the bar

2. Outreach improvement with proof

Example requests:

"Add the right customer story to this email."

"Make this outreach more credible using one of our stories."

Success criteria:

improve the message with one grounded story angle at most unless the user asks for multiple options

use only proof points supported by the matched story file

keep the message natural and avoid sounding like pasted marketing copy

omit the story entirely if it would feel stretched

3. Story-aware seller guidance

Example requests:

"Give me the best proof point to mention on the call."

"Which case study should Pat keep in reserve for this account?"

Success criteria:

name the best match, the backup match if one clearly exists, and the reason each is or is not usable

separate verified story facts from inferred relevance

recommend the safest talk track for the seller

## Methodology

Identify the prospect or account attributes that matter most for story selection:

industry or market segment

association vs corporate context

use-case or pain area

buyer or champion persona

geography when relevant

measurable business outcome or success metric

Decide which story file is the more natural starting point:

prefer the associations file for associations, member organizations, certification bodies, healthcare colleges, and similar membership or credentialing contexts

prefer the corporate file for corporate L&D, workforce development, employee onboarding, compliance, manufacturing, financial services, oil and gas, and similar enterprise contexts

check both when the fit is ambiguous or the first file produces only weak matches

Compare candidate stories using the matching rubric in references/story-source-guide.md.

Rank candidate stories conservatively. A story is strong only when at least the market context and the core use-case meaningfully align.

Extract only the most reusable proof points:

customer name

the specific use-case or transformation

1-3 measurable outcomes or concrete facts

products or services used only when relevant and supported

source link when available

Explain the match in plain language:

what aligns well

what is only directionally similar

what remains unknown

Decide whether to use the story in output:

use it directly when the match is strong enough to sound credible to the prospect

soften it when the story is only partially aligned

skip it entirely when the comparison would require too much invention

If the task includes outreach, weave in the story naturally:

prefer one short proof reference over a long mini case study

mention the customer name only when the match is strong and the source clearly supports it

if naming the customer would feel too aggressive, use an anonymized framing like "we've seen similar associations" only when the underlying story support is real

Matching Rules

Prioritize these dimensions in order:

market structure match

use-case match

outcome or success-metric match

persona relevance

geography or scale fit

Treat these as weak signals unless supported by the stronger dimensions above:

generic digital transformation language

broad learner growth claims with no use-case overlap

a shared product name alone

a shared region alone

A story should usually not be used when:

the prospect's segment differs materially from the story's segment and the use-case overlap is thin

the message would depend on inferring pains or outcomes not present in the story

the only overlap is vague growth language or online learning in general

the story is interesting but not useful for this buyer conversation

Outreach Use Rules

When using a matched story in outreach:

anchor to the prospect's role and context first, then add the proof point

keep the proof reference to one sentence or short clause unless the user asks for a longer version

use numbers only when they come directly from the story source

do not imply the prospect has the same pain, maturity, or results as the customer story

do not claim the story proves likely ROI for this prospect

do not stack multiple customer stories into one cold message unless the user explicitly asks for options

Preferred outreach pattern:

role-and-context opening

one carefully matched customer example or proof point

soft bridge to a question or next step

## Final Deliverable

When the task is primarily story matching, return a compact structured result for each prospect or account:

best_story_match

match_strength (strong, partial, or weak)

why_it_matches

safe_proof_points

risks_or_mismatches

backup_story_match

use_in_outreach (yes, soften, or no)

recommended_story_line

source_link

When the task includes outreach drafting or revision, return the story match summary first if it materially affects the drafting decision, then provide the final message.

Quality Bar

Before finalizing:

confirm the selected story is the best available grounded match, not just the most impressive story

separate story facts from inferred relevance to the prospect

include only proof points that can be traced to the attached source files

remove any story mention that makes the message feel overstated, overfit, or salesy

prefer no story over a weak story

Example

Input:

Prospect: association executive responsible for credentialing growth

Goal: improve first-touch email with a relevant customer story

Good output shape:

best story match: British Society of Lifestyle Medicine

match strength: strong

why it matches: association context, certification-style learning, revenue and engagement outcomes

safe proof points:

flexible certification programs for healthcare professionals

60,000+ hours of accredited learning delivered globally

revenue growth and conference-attendance growth from a scalable learning model

risks or mismatches:

healthcare-specific context may not transfer directly if the prospect is in another professional field

use in outreach: yes

recommended story line: "I've seen associations use Brightspace to turn certification and member education into a more scalable revenue and engagement engine-for example, the British Society of Lifestyle Medicine expanded accredited learning globally while growing income and conference participation."

Bad output shape:

picks a story only because it has big numbers

claims the prospect likely has the same problem without evidence

pastes a long marketing paragraph into the draft
