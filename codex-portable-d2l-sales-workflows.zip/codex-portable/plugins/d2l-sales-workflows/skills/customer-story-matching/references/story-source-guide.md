# Story Source Guide

Use this before matching a prospect to a D2L customer story. Prefer no story over a stretched one.

## Source Priority

1. Full CSV files under `../../references/story-files/` when present.
2. The project-level `_ All Customer Stories - Published (2).csv` when it is the only available
   exported story source.
3. User-provided story details for the current task.
4. Known preview rows from `../../references/story-assets.md`, marked as limited.

## Matching Dimensions

Rank stories by:

1. Market structure: association, credentialing body, healthcare education, corporate L&D, training
   organization, or other.
2. Use case: certification, CE, member education, onboarding, compliance, workforce training,
   monetized learning, or engagement.
3. Outcome: measurable business or learner result relevant to the prospect.
4. Persona relevance: why this buyer would care.
5. Geography, scale, and product pattern when they materially improve fit.

## Weak Signals

Treat these as insufficient on their own:

- shared geography
- broad digital transformation language
- a big brand with no use-case overlap
- generic online learning claims
- a shared product name with no matching business problem

## Proof Extraction

Pull only:

- customer name
- source file or source link
- the specific use case or transformation
- 1-3 safe proof points
- risks or mismatches that should soften the story

Do not imply the prospect has the same pain, scale, maturity, or result as the customer story.
