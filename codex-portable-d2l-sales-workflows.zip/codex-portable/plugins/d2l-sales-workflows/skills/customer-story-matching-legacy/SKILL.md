---
name: customer-story-matching-legacy
description: "Use when the task is to match a prospect, account, or outreach draft to the strongest customer story from the attached story CSVs, decide whether the match is credible enough to use, and pull only the most defensible proof points into outreach or seller notes."
---

# Customer Story Matching

Source agent: Prospect Strategy Agent (agt_6a0026e720bc8191be930c36ba48b710)
Source skill URL: https://chatgpt.com/agents/studio/edit/agt_6a0026e720bc8191be930c36ba48b710/skills/hsk_6a00c70aef8881918083d89781384047
Short description: Match prospects to the best proof points from story CSVs

## Instructions

Customer Story Matching
Overview

Use this skill when the agent needs to select the best supporting customer story for a prospect and use that proof carefully.

This skill is for evidence-backed analogy, not for generic social-proof stuffing. Its job is to find the closest credible customer story, explain why it fits, identify which proof points are safe to mention, and skip the story entirely when the match is weak.

Use these attached files as the source of truth for customer stories:

Associations Stories - Published.csv


Corporate Stories - Published.csv


When To Use This Skill

Use this skill when the user asks to:

match prospects or accounts to relevant customer stories, case studies, or proof points

strengthen outreach with customer evidence from the attached CSVs

choose which story to reference in an email, LinkedIn note, call prep, or seller brief

decide whether a prospect has a strong-enough story parallel to justify mentioning a customer example

compare multiple candidate stories and pick the most credible one

Do not use this skill when:

the task is only basic prospect scoring with no need for customer-story support

the user asks for broad story brainstorming without grounding in the attached CSVs

the best answer is to avoid social proof because the match would be stretched or misleading

Core Principle

Prefer no story over a weak story.

A customer story is usable only when the overlap is specific enough that the analogy would still feel honest if the prospect challenged it directly.

## Methodology

Identify the prospect profile that matters for matching.

Pull the organization type, industry or segment, likely use case, role context, current trigger, and any verified pain or outcome clues from the working prospect record.

Separate verified facts from inferred needs before matching.

Scan the attached CSVs for the closest comparable stories.

Use organization type and market segment first.

Then compare likely use case, business outcome, learner population, geography, and product pattern.

Treat matching on a single broad industry label alone as weak evidence.

Rank candidate stories conservatively.

A strong match usually shares at least two meaningful layers such as segment plus use case, or role-relevant problem plus measurable outcome.

Prefer stories with clear measurable impact, a similar operating model, and a clean narrative the seller can explain in one or two lines.

Prefer the tighter comparable over the bigger brand name.

Decide whether the story clears the usage bar.

Use confidently only when the overlap is strong and specific.

Use cautiously when the story is directionally relevant but one important dimension is inferred rather than verified.

Do not use when the match depends on wishful thinking, generic category overlap, or unsupported assumptions.

Extract only defensible proof points.

Pull metrics, outcomes, and use-case language directly from the CSV.

Keep them attributable to the customer story, not to the prospect.

Do not imply the prospect has the same problem, scale, constraints, or results.

Apply the story carefully in downstream output.

In outreach, use the story as a light relevance signal, not as the whole message.

In seller notes, be explicit about why the story fits and what remains uncertain.

If the story does not clear the bar, say that directly and continue without it.

Matching Criteria

Evaluate each candidate story across these dimensions:

Segment fit: association, credentialing, healthcare, training provider, corporate L&D, workforce, financial services, etc.

Use-case fit: certification, onboarding, monetized learning, learner engagement, blended delivery, channel training, member training, compliance, upskilling, or similar.

Problem similarity: the likely pain, initiative, or business goal appears genuinely comparable.

Outcome relevance: the metrics or impact would matter to this prospect's likely context.

Credibility risk: how much the match relies on inference or broad analogy.

When two stories are similar, prefer the one with:

the tighter segment fit

the more comparable use case

the cleaner metric or outcome

the lower exaggeration risk in outreach

Outreach Usage Rules

When using a matched story in outreach:

mention the story briefly and naturally

anchor the message to the prospect's verified context first

frame the story as an example of a similar organization or motion, not as proof the prospect has the same issue

use one or two proof points at most

soften the language when any part of the match is inferred

Good pattern:

"I thought of how [customer] used Brightspace to support [use case/outcome], which may be directionally relevant if [lightly framed prospect context]."

Avoid:

claiming the prospect has the same pain without proof

stacking multiple weak stories to create fake confidence

dropping metrics with no explanation of why the example is relevant

using customer logos or outcomes as generic prestige filler

pretending a corporate story cleanly maps to an association prospect, or vice versa, unless the use case overlap is unusually strong and clearly stated

## Final Deliverable

When story matching is the main task, return a structured result for each prospect or target with:

best_story_match.customer

best_story_match.source_file

best_story_match.match_level (use_confidently, use_cautiously, or do_not_use)

best_story_match.match_rationale

best_story_match.shared_attributes

best_story_match.open_uncertainties

best_story_match.safe_proof_points

best_story_match.outreach_usage_note

best_story_match.alternative_story_candidates

When the user mainly wants outreach or seller notes, embed a compact version of the same judgment in the relevant output rather than forcing a separate large section.

Quality Bar

Before using a story, confirm that:

the match is driven by specific overlap, not vague category similarity

every proof point came from the attached CSVs

the outreach wording does not overclaim what is known about the prospect

any uncertainty is preserved instead of hidden

the chosen story improves relevance more than it increases exaggeration risk

If those conditions are not met, do not use the story.

Example

If the prospect is a membership or credentialing organization trying to grow professional education revenue, a story like British Society of Lifestyle Medicine may be a strong candidate because the overlap includes certification-style learning, revenue growth, and scalable learning delivery. In that case, it can be used carefully as a similar example.

If the prospect is only vaguely "education related" with no verified certification, member training, or monetization angle, do not force that story into outreach.
